<html>
    <head>
        <title>Test connexion</title>
    </head>
    <body>

        <h3>Vous vous êtes connecté avec succès ! ٩(๑`^´๑)۶</h3>

        <p><?php echo anchor('Verifco/connexion', 'Try it again!'); ?></p>
        
        <p><div><a href="/CVVEN/index.php/verif/connexion"><input type="submit" value="Se connecter" /></a></div></p>
    </body>
</html>
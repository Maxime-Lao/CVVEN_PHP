<html>
    <head>
        <title>Changer de mot de passe</title>
    </head>
    <body>
        <h5>Email de l'utilisateur :</h5>
        <input type='text' name='mel' value='' size='50' />
        
        <h5>Nouveau mot de passe :</h5>
        <input type='password' name='nmdp' value='' size='50' />
        
        <h5>Confirmer le nouveau mot de passe :</h5>
        <input type='password' name='vmdp' value='' size='50' />
        
        <br/>
        <br/>
        <div><input type="submit" name="submit" value="Valider" /></div>
    </body>
</html>

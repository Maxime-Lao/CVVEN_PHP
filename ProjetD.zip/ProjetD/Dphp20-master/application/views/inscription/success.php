<html>
    <head>
        <title>Inscription</title>
    </head>
    <body>

        <h3>Votre compte a été enregistré avec succès ! ٩(๑`^´๑)۶</h3>
        
        <p><div><a href="/CVVEN/index.php/verifco/connexion"><input type="submit" value="Se connecter" /></a></div></p>

        <p><?php echo anchor('Verif/create', 'Try it again!'); ?></p>
    </body>
</html>
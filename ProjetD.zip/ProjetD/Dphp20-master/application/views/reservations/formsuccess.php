<html>
<head>
<title>Reservations</title>
</head>
<body>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<h3><center><p style="color: #e89999  ">Votre réservation a bien été enregistrée!</p></center></h3>

<p><center><?php echo anchor('Reservations/savedata', 'Revenir'); ?></center></p>

</body>
</html>
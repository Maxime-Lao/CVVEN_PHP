<html>
<head>
<title>Reservations</title>
</head>
<body>
    <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<h3><center><p style="color: #e89999  ">Cette réservation a bien été éffacée!</p></center></h3>

<p><center><?php echo anchor('Reservations/show', 'Revenir'); ?></center></p>

</body>
</html>

<!DOCTYPE html>
<html>
    <head>
        <script src="vendor/bootstrap/js/bootstrap.min.js"></script>    
        <link rel="stylesheet" href="<?php echo base_url('vendor/bootstrap/css/Formu.css'); ?>"  rel="stylesheet">
        <link rel="stylesheet" href="<?php echo base_url('vendor/bootstrap/css/form.css'); ?>"  rel="stylesheet">
        <meta charset="UTF-8">

    </head>
    <body>
